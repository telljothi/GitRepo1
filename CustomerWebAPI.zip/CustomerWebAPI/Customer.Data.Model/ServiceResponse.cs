﻿namespace Customer.Data.Model
{
    public class ServiceResponse
    {
        public string ActionStatus { get; set; }
        public string ActionStatusMessage { get; set; }
        public int ActionStatusCode { get; set; }
        public string CorrelationId { get; set; }
        public string ResponseData { get; set; }
        public string RequestedDateTime { get; set; }
        public string RespondedDateTime { get; set; }
    }
}
