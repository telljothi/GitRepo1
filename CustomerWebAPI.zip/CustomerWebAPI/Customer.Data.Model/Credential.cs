﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Customer.Data.Model
{
    public class Credential
    {
        [Required]
        public string UserId { get; set; }
        [Required]
        public string Password { get; set; }
    }
}
