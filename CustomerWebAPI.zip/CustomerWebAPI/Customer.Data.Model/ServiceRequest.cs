﻿using System.ComponentModel.DataAnnotations;

namespace Customer.Data.Model
{
    public class ServiceRequest
    {
        [Required]
        public string CorrelationId { get; set; }
        [Required]
        public string RequestData { get; set; }
    }
}
