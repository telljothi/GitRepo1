﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Customer.Global
{
    public class StoredprocedureConstants
    {
        public const string Get_CustomerbyID = "Get_CustomerbyID",
            Get_CustomerByEmail = "Get_CustomerByEmail",
            Create_Customer = "Create_Customer",
            Delete_CustomerById = "Delete_CustomerById",
            DeleteCustomer = "DeleteCustomer",
            InsertCustomer= "InsertCustomer",
            UpdateCustomer= "UpdateCustomer";
    }

    public class Messages
    {
        public const string CustomerCreated = "Customer Created",
            ErrorOccured = "Technical Error occured",
            CustomerUpdated = "Customer Updated",
            ErrorinDelete = "Error occured while deleting";
    }
}
