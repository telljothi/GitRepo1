﻿using System;

namespace Customer.Global
{
    public class ActionStatus
    {
        public const string OK = "OK",
            FAILED = "FAILED",
            NORECORD = "NORECORD",
            ERROR = "ERROR",
            ONHOLD = "ONHOLD";
    }

    public class ActionStatusCode
    {
        public const int OK = 200,
            ValidationFailures = 300,
            RecordNotFound = 404,
            MethodFailure = 420,
            DataSaved = 700,
            RecordAlreadyExists = 405;
    }

    public class ActionStatusMessage
    
    {
        public const string OK = "OK",
            DataSaved = "Data Saved",
            Unauthorized = "Unauthorized",
            RecordNotFound = "Record not found",
            ValidationFailures = "Validation failure",
            RecordAlreadyExists ="Record already exists",
            RecordAlreadyExistsbyEmail = "Record already exists with eMail",
            RecordDeleted = "Record deleted";
            
    }

}
