﻿using Customer.Data.Connector;
using Customer.Data.Model;
using Customer.Global;
using Microsoft.Extensions.Configuration;

namespace Customer.Process
{
    public class CustomerProcess
    {   
        private readonly CommonProcess commonProcess;
        private readonly IConfiguration _config;

        public CustomerProcess(IConfiguration config)
        {
            _config = config;
            commonProcess = new CommonProcess();
        }

        public ServiceResponse GetCustomer(int Id)
        {
            ServiceResponse response = null;
            try
            {
                var result = new CustomerConnector(_config).GetCustomer(Id);
                if (result.Length <= 2)
                {
                    response = commonProcess.ResultResponse(ActionStatusCode.RecordNotFound, ActionStatusMessage.RecordNotFound);
                }
                else
                {
                    response = commonProcess.ResultResponse(ActionStatusCode.OK, ActionStatusMessage.OK);
                    response.ResponseData = result;
                }
            }
            catch 
            {
                return commonProcess.ResultResponse(ActionStatusCode.MethodFailure, Messages.ErrorOccured);
            }
            return response;
        }

        public ServiceResponse GetCustomerByeMail(string eMail)
        {
            ServiceResponse response = null;
            try
            {
                int result = new CustomerConnector(_config).GetCustomerByeMail(eMail);
                if (result >= 1)
                {
                    response = commonProcess.ResultResponse(ActionStatusCode.RecordAlreadyExists, ActionStatusMessage.RecordAlreadyExists);
                }
                else
                {
                    response = commonProcess.ResultResponse(ActionStatusCode.OK, ActionStatusMessage.OK);
                }
            }
            catch
            {
                return commonProcess.ResultResponse(ActionStatusCode.MethodFailure, Messages.ErrorOccured);
            }
            return response;
        }

        public ServiceResponse CreateCustomer(CustomerRequest customer)
        {            
            try
            {
                var result = new CustomerConnector(_config).CreateCustomer(customer);
                return commonProcess.ResultResponse(ActionStatusCode.DataSaved, Messages.CustomerCreated);
            }
            catch
            {
                return commonProcess.ResultResponse(ActionStatusCode.MethodFailure, Messages.ErrorOccured);
            }
        }

        public ServiceResponse UpdateCustomer(CustomerRequest customer)
        {           
            try
            {
                var result = new CustomerConnector(_config).UpdateCustomer(customer);
                return commonProcess.ResultResponse(ActionStatusCode.DataSaved, Messages.CustomerUpdated);
            }
            catch
            {
                return commonProcess.ResultResponse(ActionStatusCode.MethodFailure, Messages.ErrorOccured);
            }
        }

        public ServiceResponse DeleteCustomer(int customerId)
        {
            ServiceResponse response = null;
            try
            {
                int result = new CustomerConnector(_config).DeleteCustomer(customerId);
                if (result >= 1)
                {
                    response = commonProcess.ResultResponse(ActionStatusCode.OK, ActionStatusMessage.RecordDeleted);
                }
                else
                {
                    response = commonProcess.ResultResponse(ActionStatusCode.MethodFailure,Messages.ErrorinDelete);
                }
            }
            catch
            {
                return commonProcess.ResultResponse(ActionStatusCode.MethodFailure, Messages.ErrorOccured);
            }
            return response;
        }
    }
}
