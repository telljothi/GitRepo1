﻿using Customer.Data.Model;
using Customer.Global;
using System;

namespace Customer.Process
{
    public class CommonProcess
    {
        public ServiceResponse ResultResponse(int actionStatusCode, string actionStatusMessage = null)
        {
            switch (actionStatusCode)
            {
                case ActionStatusCode.OK:
                    {
                        return new ServiceResponse
                        {
                            RequestedDateTime = DateTime.Now.ToString(),
                            RespondedDateTime = DateTime.Now.ToString(),
                            ActionStatus = ActionStatus.OK,
                            ActionStatusCode = ActionStatusCode.OK,
                            ActionStatusMessage = actionStatusMessage
                        };
                    }
                case ActionStatusCode.DataSaved:
                    {
                        return new ServiceResponse
                        {
                            RequestedDateTime = DateTime.Now.ToString(),
                            RespondedDateTime = DateTime.Now.ToString(),
                            ActionStatus = ActionStatus.OK,
                            ActionStatusCode = ActionStatusCode.DataSaved,
                            ActionStatusMessage = actionStatusMessage
                        };
                    }
                case ActionStatusCode.ValidationFailures:
                    {
                        return new ServiceResponse
                        {
                            RequestedDateTime = DateTime.Now.ToString(),
                            RespondedDateTime = DateTime.Now.ToString(),
                            ActionStatus = ActionStatus.ERROR,
                            ActionStatusCode = ActionStatusCode.ValidationFailures,
                            ActionStatusMessage = actionStatusMessage
                        };
                    }
                case ActionStatusCode.RecordNotFound:
                    {
                        return new ServiceResponse
                        {
                            RequestedDateTime = DateTime.Now.ToString(),
                            RespondedDateTime = DateTime.Now.ToString(),
                            ActionStatus = ActionStatus.NORECORD,
                            ActionStatusCode = ActionStatusCode.RecordNotFound,
                            ActionStatusMessage = actionStatusMessage
                        };
                    }
                case ActionStatusCode.RecordAlreadyExists:
                    {
                        return new ServiceResponse
                        {
                            RequestedDateTime = DateTime.Now.ToString(),
                            RespondedDateTime = DateTime.Now.ToString(),
                            ActionStatus = ActionStatus.FAILED,
                            ActionStatusCode = ActionStatusCode.RecordAlreadyExists,
                            ActionStatusMessage = actionStatusMessage
                        };
                    }

                default:
                    return null;
            }
        }
    }
}
