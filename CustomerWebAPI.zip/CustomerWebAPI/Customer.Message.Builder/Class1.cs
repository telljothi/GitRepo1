﻿using System;

namespace Customer.Message.Builder
{
    public class Class1
    {
    }
}
