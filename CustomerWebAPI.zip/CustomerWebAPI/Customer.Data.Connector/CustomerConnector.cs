﻿using Customer.Data.Model;
using Customer.Global;
using Dapper;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System.Data;
using System.Data.SqlClient;

namespace Customer.Data.Connector
{
    public class CustomerConnector
    {
        private readonly string _connString;
        private readonly IConfiguration _config;

        public CustomerConnector(IConfiguration configuration)
        {
            _config = configuration;
            _connString = _config["ConnectionStrings:CustomerDatabase"];
        }

        public string GetCustomer(int Id)
        {
            using (SqlConnection con = new SqlConnection(_connString))
            {                
                var values = new { Id = Id };              
                string  results = JsonConvert.SerializeObject(con.Query(StoredprocedureConstants.Get_CustomerbyID, values, commandType: CommandType.StoredProcedure));
                return results;
            }            
        }

        public int GetCustomerByeMail(string eMail)
        {
            using (SqlConnection con = new SqlConnection(_connString))
            {               
                var paramValues = new { Email = eMail };
                int  result = con.ExecuteScalar<int>(StoredprocedureConstants.Get_CustomerByEmail, paramValues, commandType: CommandType.StoredProcedure);
                return result;
            }
        }

        public int CreateCustomer(CustomerRequest customer)
        {
            using (SqlConnection con = new SqlConnection(_connString))
            {             
                var parameters = new { FirstName = customer.CustomerInfo.FirstName, 
                    LastName = customer.CustomerInfo.LastName,
                    Gender=customer.CustomerInfo.Gender,
                    Email = customer.CustomerInfo.Email,
                    City = customer.CustomerInfo.City, 
                    PostBox = customer.CustomerInfo.PostBox,
                    Mobile = customer.CustomerInfo.Mobile};
                int identity =  con.ExecuteScalar<int>(StoredprocedureConstants.InsertCustomer, parameters, commandType: CommandType.StoredProcedure);
                return identity;
            }
        }

        public int DeleteCustomer(int customerId)
        {
            using (SqlConnection con = new SqlConnection(_connString))
            {               
                var paramValues = new { Id = customerId };
                int result = con.ExecuteScalar<int>(StoredprocedureConstants.DeleteCustomer, paramValues, commandType: CommandType.StoredProcedure);
                return result;
            }
        }

        public int UpdateCustomer(CustomerRequest customer)
        {
            using (SqlConnection con = new SqlConnection(_connString))
            {                
                var parameters = new
                {
                    Id = customer.CustomerInfo.Id,
                    FirstName = customer.CustomerInfo.FirstName,
                    LastName = customer.CustomerInfo.LastName,
                    Gender = customer.CustomerInfo.Gender,
                    Email = customer.CustomerInfo.Email,
                    City = customer.CustomerInfo.City,
                    PostBox = customer.CustomerInfo.PostBox,
                    Mobile = customer.CustomerInfo.Mobile
                };
                int identity = con.ExecuteScalar<int>(StoredprocedureConstants.UpdateCustomer, parameters, commandType: CommandType.StoredProcedure);
                return identity;
            }
        } 
    }
}
