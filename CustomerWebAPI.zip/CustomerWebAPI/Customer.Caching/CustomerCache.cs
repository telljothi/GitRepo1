﻿using System;

namespace Customer.Caching
{
    public class CustomerCache
    {
    }
}
