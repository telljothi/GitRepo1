﻿using System;

namespace Customer.Data.Access
{
    public class CustomerRepository
    {
    }
}
