﻿using System.Text.Json;

namespace Customer.Helpers
{
    public static class SerializationHelper
    {
        public static T GetJsonDeserilizedObject<T>(this string toDeserialize)
        {
            try
            {
                JsonSerializerOptions options = new JsonSerializerOptions();
                options.IgnoreNullValues = true;
                return JsonSerializer.Deserialize<T>(toDeserialize, options);
            }
            catch 
            {
                throw;
            }
        }
    }
}
