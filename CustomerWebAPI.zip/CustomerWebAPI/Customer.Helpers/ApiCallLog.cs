﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;

namespace Customer.Helpers
{
    
       
        public class ApiCallLogModel
        { 
            public string CorrelationId { get; set; }
            public string RequestData { get; set; }
            public string ResponseData { get; set; }

        }
        
    
}
