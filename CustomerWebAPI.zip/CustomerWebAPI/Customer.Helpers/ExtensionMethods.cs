﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Linq;
using System.Text.RegularExpressions;

namespace Customer.Helpers
{
    public static class ExtensionMethods
    {
        public static bool ValidateObjectModel<T>(this T requestObject, out List<ValidationResult> validationResults)
        {
            var validationContext = new ValidationContext(requestObject, serviceProvider: null, items: null);
            validationResults = new List<ValidationResult>();
            return Validator.TryValidateObject(requestObject, validationContext, validationResults, validateAllProperties: true);
        }
    }
}
