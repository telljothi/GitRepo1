﻿using Customer.Data.Model;
using Customer.Global;
using Customer.Helpers;
using Customer.Process;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CustomerWebAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CustomerServiceController : BaseController
    {
        private readonly CommonProcess commonProcess;
        private readonly IConfiguration _config;

        public CustomerServiceController(IConfiguration configuration) : base(configuration)
        {
            _config = configuration;
            commonProcess = new CommonProcess();
        }

        [HttpPost("GetCustomer")]
        public ServiceResponse GetCustomer([FromBody] ServiceRequest serviceRequest)
        {
            ServiceResponse serviceResponse;
            try
            {
                GetCustomer request = GetClearObjectFromJson<GetCustomer>(serviceRequest.RequestData);

                if (request == null)
                {                   
                    serviceResponse = commonProcess.ResultResponse(ActionStatusCode.ValidationFailures, ActionStatusMessage.ValidationFailures);
                    return serviceResponse;
                }
                var validationResults = new List<ValidationResult>();

                if (request.ValidateObjectModel(out validationResults))
                {                   
                    var process = new CustomerProcess(_config);
                    return process.GetCustomer(request.CustomerId);
                }
                else
                {
                    serviceResponse = commonProcess.ResultResponse(ActionStatusCode.ValidationFailures, String.Join(",", validationResults));
                }
                return serviceResponse;
            }
            catch 
            {
                return commonProcess.ResultResponse(ActionStatusCode.MethodFailure);
            }
        }

        [HttpPost("CreateCustomer")]
        public ServiceResponse CreateCustomer([FromBody] ServiceRequest serviceRequest)
        {
            ServiceResponse serviceResponse;
            try
            {
                CustomerRequest request = GetClearObjectFromJson<CustomerRequest>(serviceRequest.RequestData);

                if (request == null)
                {
                    serviceResponse = commonProcess.ResultResponse(ActionStatusCode.ValidationFailures, ActionStatusMessage.ValidationFailures);
                }
                var validationResults = new List<ValidationResult>();

                if (request.CustomerInfo.ValidateObjectModel(out validationResults))
                {
                    var process = new CustomerProcess( _config);

                    var result = process.GetCustomerByeMail(request.CustomerInfo.Email);
                    if (result != null)
                    {
                        if (result.ActionStatusCode == ActionStatusCode.RecordAlreadyExists)
                        {
                            return serviceResponse = commonProcess.ResultResponse(ActionStatusCode.RecordAlreadyExists, ActionStatusMessage.RecordAlreadyExistsbyEmail);
                        }
                    }
                    return process.CreateCustomer(request);
                }
                else
                {
                    serviceResponse = commonProcess.ResultResponse(ActionStatusCode.ValidationFailures, String.Join(",", validationResults));
                }
                return serviceResponse;
            }
            catch
            {
                return commonProcess.ResultResponse(ActionStatusCode.MethodFailure);
            }
        }

        [HttpPost("DeleteCustomer")]
        public ServiceResponse DeleteCustomer([FromBody] ServiceRequest serviceRequest)
        {
            ServiceResponse serviceResponse;
            try
            {
                GetCustomer request = GetClearObjectFromJson<GetCustomer>(serviceRequest.RequestData);

                if (request == null)
                {
                    serviceResponse = commonProcess.ResultResponse(ActionStatusCode.ValidationFailures, ActionStatusMessage.ValidationFailures);
                    return serviceResponse;
                }
                var validationResults = new List<ValidationResult>();

                if (request.ValidateObjectModel(out validationResults))
                {
                    var process = new CustomerProcess(_config);

                    var result = process.GetCustomer(request.CustomerId);
                    if (result != null && result.ActionStatusCode == ActionStatusCode.RecordNotFound)
                    { 
                      return commonProcess.ResultResponse(ActionStatusCode.RecordNotFound, ActionStatusMessage.RecordNotFound);
                    }
                    return process.DeleteCustomer(request.CustomerId);
                }
                else
                {
                    serviceResponse = commonProcess.ResultResponse(ActionStatusCode.ValidationFailures, String.Join(",", validationResults));
                }
                return serviceResponse;
            }
            catch 
            {
                return commonProcess.ResultResponse(ActionStatusCode.MethodFailure);
            }
        }

        [HttpPost("UpdateCustomer")]
        public ServiceResponse UpdateCustomer([FromBody] ServiceRequest serviceRequest)
        {
            ServiceResponse serviceResponse;
            try
            {
                CustomerRequest request = GetClearObjectFromJson<CustomerRequest>(serviceRequest.RequestData);

                if (request == null)
                {
                    serviceResponse = commonProcess.ResultResponse(ActionStatusCode.ValidationFailures, ActionStatusMessage.ValidationFailures);
                }
                var validationResults = new List<ValidationResult>();

                if (request.CustomerInfo.ValidateObjectModel(out validationResults))
                {
                    var process = new CustomerProcess(_config);

                    var result = process.GetCustomer(request.CustomerInfo.Id);
                    if (result != null && result.ActionStatusCode == ActionStatusCode.RecordNotFound)
                    {
                        return commonProcess.ResultResponse(ActionStatusCode.RecordNotFound, ActionStatusMessage.RecordNotFound);
                    }
                    return process.UpdateCustomer(request);
                }
                else
                {
                    serviceResponse = commonProcess.ResultResponse(ActionStatusCode.ValidationFailures, String.Join(",", validationResults));
                }
                return serviceResponse;
            }
            catch 
            {
                return commonProcess.ResultResponse(ActionStatusCode.MethodFailure);
            }
        }
    }
}
