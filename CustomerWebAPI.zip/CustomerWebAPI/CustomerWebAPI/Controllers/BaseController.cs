﻿using Customer.Data.Model;
using Customer.Global;
using Customer.Helpers;
using Customer.Process;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CustomerWebAPI.Controllers
{
    public class BaseController : Controller
    {
        private readonly IConfiguration _config;
        private readonly CommonProcess commonProcess;
        public readonly bool IsEncryptedRequest;

        public BaseController(IConfiguration configuration)
        {
            _config = configuration;
            commonProcess = new CommonProcess(); 
        }

        protected T GetClearObjectFromJson<T>(string encryptedJson)
        {
            try
            {
                return GetClearJson(encryptedJson).GetJsonDeserilizedObject<T>();
            }
            catch 
            {
                return default;
            }
        }

        protected string GetClearJson(string encryptedJson)
        {               
            return encryptedJson;            
        }
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            try
            {
                var serviceResponse = new ServiceResponse();
                ApiCallLogModel logRequestModel = null;

                if (context.ActionArguments.ContainsKey("servicerequest"))
                {
                    ServiceRequest serviceRequest = (ServiceRequest)context.ActionArguments["servicerequest"];

                    logRequestModel = new ApiCallLogModel
                    {
                        CorrelationId = serviceRequest.CorrelationId,
                         RequestData  = serviceRequest.RequestData
                    };

                    if (serviceRequest is null)
                    {
                        serviceResponse = commonProcess.ResultResponse(ActionStatusCode.MethodFailure, $"Invaid request from client");
                    }
                    var validateResults = new List<ValidationResult>();
                    if (serviceRequest.ValidateObjectModel(out validateResults))
                    {
                        serviceResponse.CorrelationId = serviceRequest.CorrelationId;
                        var plainJsonRequestData = serviceRequest.RequestData;
                        serviceResponse.ResponseData = plainJsonRequestData;
                        context.HttpContext.Items["LogRequestModel"] = logRequestModel;
                    }
                }                
            }
            catch 
            {
            }
        }

        public override void OnActionExecuted(ActionExecutedContext context)
        {
            base.OnActionExecuted(context);
            ServiceResponse serviceResponse = null;
            var logRequestModel = new ApiCallLogModel();

            if (context.HttpContext.Items.Count > 0)
            {
                logRequestModel = (ApiCallLogModel)context.HttpContext.Items["LogRequestModel"];

            }
            IActionResult contextResult = context.Result;
            if (context.Result.GetType().Name == "ObjectResult")
            {

                serviceResponse = ((ObjectResult)contextResult)?.Value as ServiceResponse;
                if (serviceResponse is null)
                {
                    serviceResponse = commonProcess.ResultResponse(ActionStatusCode.ValidationFailures);

                }
                serviceResponse.CorrelationId = logRequestModel.CorrelationId;
                serviceResponse.ResponseData = serviceResponse.ResponseData;
            }

            context.Result = new ObjectResult(serviceResponse)
            {
                DeclaredType = typeof(ServiceResponse)
            };           
        }
    }
}
