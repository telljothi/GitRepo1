﻿using System;

namespace Customer.APIConsumer
{
    public class Class1
    {

    }
}
