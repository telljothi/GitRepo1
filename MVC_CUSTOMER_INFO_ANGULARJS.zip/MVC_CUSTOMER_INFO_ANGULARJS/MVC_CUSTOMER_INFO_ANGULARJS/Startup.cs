﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(MVC_CUSTOMER_INFO_ANGULARJS.Startup))]
namespace MVC_CUSTOMER_INFO_ANGULARJS
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
           
        }
    }
}
