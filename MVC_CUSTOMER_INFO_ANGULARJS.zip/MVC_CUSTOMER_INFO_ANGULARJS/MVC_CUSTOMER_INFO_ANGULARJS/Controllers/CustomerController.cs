﻿using MVC_CUSTOMER_INFO_ANGULARJS.Models;
using MVC_CUSTOMER_INFO_ANGULARJS.Repository;
using System;
using System.Collections.Generic;
using System.Web.Mvc;

namespace MVC_CUSTOMER_INFO_ANGULARJS.Controllers
{
    public class CustomerController : Controller
    {
        CustomerRepository rep = new CustomerRepository();

        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public JsonResult GetAllCustomers()
        {
            List<Customer> obj = rep.SelectAllCustomers();
            return Json(obj, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public JsonResult GetCustomerById(int id)
        {
            Customer obj = rep.SelectAllCustomers().Find(x => x.Id.Equals(id));
            return Json(obj, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public void InsertCustomer(Customer st)
        {
            rep.InsertCustomer(st);
        }

        [HttpPost]
        public void UpdateCustomer(Customer st)
        {
            rep.UpdateCustomer(st);
        }

        [HttpPost]
        public void DeleteCustomer(int id)
        {
            rep.DeleteCustomer(id);
        }
    }
}
