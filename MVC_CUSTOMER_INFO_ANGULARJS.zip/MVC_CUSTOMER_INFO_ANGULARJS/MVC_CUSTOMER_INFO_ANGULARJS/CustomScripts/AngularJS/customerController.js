﻿customerApp.controller("customerAngularController", function ($scope, customerAngularService) {

    //GET ALL Customers
    GetAllCustomers();
    function GetAllCustomers() {
        var stObj = customerAngularService.getAllCustomers();
        stObj.then(function (st) {
            $scope.Customers = st.data;
        }, function (error) {

        })
    }

    //GET AN Customer
    $scope.GetAnCustomer = function (st) {
        var stObj = customerAngularService.getCustomerById(st);
        stObj.then(function (response) {
            if (response.data) {
                $scope.Id = response.data.Id
                $scope.firstname = response.data.FirstName;
                $scope.lastname = response.data.LastName;
                $scope.gender = response.data.Gender;
                $scope.email = response.data.eMail;
                $scope.postbox = response.data.PostBox;
                $scope.mobile = response.data.Mobile;
                $scope.city = response.data.City;

                $('#Id').val($scope.Id);
                $('#firstname').val($scope.firstname);
                $('#lastname').val($scope.lastname);
                $('#gender').val($scope.gender);
                $('#email').val($scope.email);
                $('#postbox').val($scope.postbox);
                $('#mobile').val($scope.mobile);
                $('#city').val($scope.city);


                $('#customerModal').modal('show');
                $('#btnUpdate').show();
                $('#btnAdd').hide();

                $('#firstname').css('border-color', 'lightgrey');
                $('#lastname').css('border-color', 'lightgrey');
                $('#gender').css('border-color', 'lightgrey');
                $('#email').css('border-color', 'lightgrey');
                $('#postbox').css('border-color', 'lightgrey');
                $('#mobile').css('border-color', 'lightgrey');
                $('#city').css('border-color', 'lightgrey');

            }
        }, function (error) {

        })
    }

    //INSERT Customer
    $scope.InsertCustomer = function () {
        var val = Validation();
        if (val == false) {
            return false;
        }
        var stObject = {
            firstName: $scope.firstname,
            lastName: $scope.lastname,
            gender: $scope.gender,
            eMail: $scope.email,
            mobile: $scope.mobile,
            city: $scope.city,
            postbox: $scope.postbox
        };
        var stObj = customerAngularService.insertCustomer(stObject);
        stObj.then(function (success) {
            GetAllCustomers();
            $('#customerModal').modal('hide');
            $('body').removeClass('modal-open');
            $('.modal-backdrop').remove();
        }, function (error) {

        })
    }

    //UPDATE Customer
    $scope.UpdateCustomer = function () {
        var val = Validation();
        if (val == false) {
            return false;
        }
        var stObject = {
            Id: $scope.Id,
            FirstName: $scope.firstname,
            LastName: $scope.lastname,
            Gender: $scope.gender,
            eMail: $scope.email,
            mobile: $scope.mobile,
            city: $scope.city,
            postbox: $scope.postbox
        };
        var stObj = customerAngularService.updateCustomer(stObject);
        stObj.then(function (response) {
            GetAllCustomers();
            $('#customerModal').modal('hide');
        }, function (error) {

        })
    }

    //DELETE Customer
    $scope.DeleteCustomer = function (st) {
        var retVal = confirm("Do you really want to delete?");
        if (retVal == true) {
            var stObj = customerAngularService.deleteCustomer(st);
            stObj.then(function (success) {
                GetAllCustomers();
            }, function (error) {

            })
            return true;
        } else {
            return false;
        }
    }

    $scope.ClearForm = function () {
        $scope.Id = "";
        $scope.firstname = "";
        $scope.lastname = "";
        $scope.email = "";
        $scope.mobile = "";
        $scope.postbox = "";
        $scope.gender = "";
        $scope.city = "";


        $('#btnUpdate').hide();
        $('#btnAdd').show();

        $('#firstname').css('border-color', 'lightgrey');
        $('#lastname').css('border-color', 'lightgrey');
        $('#gender').css('border-color', 'lightgrey');
        $('#email').css('border-color', 'lightgrey');
        $('#mobile').css('border-color', 'lightgrey');
        $('#city').css('border-color', 'lightgrey');
        $('#postbox').css('border-color', 'lightgrey');

    }

    function Validation() {
        var isValid = true;

        if ($('#firstname').val().trim() == "") {
            $('#firstname').css('border-color', 'red');
            isValid = false;
        }
        else {
            $('#firstname').css('border-color', 'lightgrey');
        }

        if ($('#lastname').val().trim() == "") {
            $('#lastname').css('border-color', 'red');
            isValid = false;
        }
        else {
            $('#lastname').css('border-color', 'lightgrey');
        }

        if ($('#email').val().trim() == "") {
            $('#email').css('border-color', 'red');
            isValid = false;
        }
        else {
            $('#email').css('border-color', 'lightgrey');
        }
        if ($('#gender').val().trim() == "") {
            $('#gender').css('border-color', 'red');
            isValid = false;
        }
        else {
            $('#gender').css('border-color', 'lightgrey');
        }

        if ($('#mobile').val().trim() == "") {
            $('#mobile').css('border-color', 'red');
            isValid = false;
        }
        else {
            $('#mobile').css('border-color', 'lightgrey');
        }

        if ($('#city').val().trim() == "") {
            $('#city').css('border-color', 'red');
            isValid = false;
        }
        else {
            $('#city').css('border-color', 'lightgrey');
        }

        var vgender = $('#gender').val().trim().toLowerCase();
        if (vgender != 'male' && vgender != 'female') {
            alert('Gender should be Male or Female');
            $('#gender').css('border-color', 'red');
            $('#gender').focus();
            isValid = false;
        }
        else {
            $('#gender').css('border-color', 'lightgrey');
        }

        var veMail = $('#email').val().trim();        
        var atpos = veMail.indexOf("@");
        var dotpos = veMail.lastIndexOf(".");
        if (atpos < 1 || (dotpos - atpos < 2)) {
            alert('Please enter valid email');
            $('#email').css('border-color', 'red');
            $('#email').focus();
            isValid = false;
        }
        return isValid;
    }
});