﻿var customerApp = angular.module("customerAngularApp", [])

