﻿customerApp.service("customerAngularService", function ($http) {
    //GET ALL Customers
    this.getAllCustomers = function () {
        var response = $http({
            method: 'GET',
            url: 'Customer/GetAllCustomers',
            dataType: 'json',
            contentType: 'application/json; charset=utf-8'
        });
        return response;
    }

    //GET Customer    
    this.getCustomerById = function (st) {
        var response = $http({
            method: 'GET',
            url: 'Customer/GetCustomerById',
            params: {
                id: st.Id
            },
            dataType: 'json',
            contentType: 'application/json; charset=utf-8'
        });
        return response;
    }

    //INSERT Customer
    this.insertCustomer = function (stObject) {       
        var response = $http({
            method: 'POST',
            url: 'Customer/InsertCustomer',
            data: JSON.stringify(stObject),
            dataType: 'json',
            contentType: 'application/json; charset=utf-8'
        });
        return response;
    }

    //UPDATE Customer
    this.updateCustomer = function (stObject) {        
        var response = $http({
            method: 'POST',
            url: 'Customer/UpdateCustomer',
            data: JSON.stringify(stObject),
            dataType: 'json',
            contentType: 'application/json; charset=utf-8'
        });
        return response;
    }

    //DELETE Customer
    this.deleteCustomer = function (st) {
        var response = $http({
            method: 'POST',
            url: 'Customer/DeleteCustomer',
            params: {
                id: st.Id
            },
            dataType: 'json',
            contentType: 'application/json; charset=utf-8'
        });
        return response;
    }   
});