﻿using System;
using System.ComponentModel.DataAnnotations;

namespace MVC_CUSTOMER_INFO_ANGULARJS.Models
{
    public class Customer
    {
        public int Id { get; set; }

        [Required]
        [StringLength(50, MinimumLength = 3, ErrorMessage = "First name should be minimum 3 to maximum 50 characters.")]
        public string FirstName { get; set; }
        [StringLength(50, MinimumLength = 3, ErrorMessage = "Last name should be minimum 3 to maximum 50 characters.")]

        [Required]
        public string LastName { get; set; }

        [StringLength(10, MinimumLength = 3, ErrorMessage = "Gender should be minimum 3 to maximum 10 characters.")]

        [Required]
        public string Gender { get; set; }

        [StringLength(50, MinimumLength = 10, ErrorMessage = "Email should be minimum 10 to maximum 50 characters.")]
        [Required]
        public string eMail { get; set; }

        [StringLength(50, MinimumLength = 5, ErrorMessage = "City should be minimum 5 to maximum 50 characters.")]
        [Required]
        public string City { get; set; }

        [StringLength(50, MinimumLength = 10, ErrorMessage = "Mobile should be minimum 10 to maximum 50 characters.")]
        [Required]
        public string Mobile { get; set; }

        [StringLength(10, MinimumLength = 1, ErrorMessage = "Postbox should be minimum 1 to maximum 10 characters.")]
        public string PostBox { get; set; }
    }
}