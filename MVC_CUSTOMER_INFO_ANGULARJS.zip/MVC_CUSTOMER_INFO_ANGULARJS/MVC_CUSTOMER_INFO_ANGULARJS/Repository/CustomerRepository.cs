﻿using MVC_CUSTOMER_INFO_ANGULARJS.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace MVC_CUSTOMER_INFO_ANGULARJS.Repository
{
    public class CustomerRepository : ICustomerRepository
    {
        string conString = ConfigurationManager.ConnectionStrings["CustomerDatabase_ConString"].ToString();
        List<Customer> customerList = new List<Customer>();
        public List<Models.Customer> SelectAllCustomers()
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SelectCustomer", con);
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader dr = dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    customerList.Add(
                        new Customer
                        {
                            Id = Convert.ToInt32(dr["Id"]),
                            FirstName = dr["FirstName"].ToString(),
                            LastName = dr["LastName"].ToString(),
                            Gender = dr["Gender"].ToString(),
                            eMail = dr["eMail"].ToString(),
                            City = dr["City"].ToString(),
                            Mobile = dr["Mobile"].ToString(),
                            PostBox = dr["PostBox"].ToString()
                        }
                        );
                };
            }
            return customerList;
        }

        public void InsertCustomer(Models.Customer st)
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("InsertCustomer", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@FirstName", st.FirstName);
                cmd.Parameters.AddWithValue("@LastName", st.LastName);
                cmd.Parameters.AddWithValue("@Gender", st.Gender);
                cmd.Parameters.AddWithValue("@eMail", st.eMail);
                cmd.Parameters.AddWithValue("@Mobile", st.Mobile);
                cmd.Parameters.AddWithValue("@City", st.City);  
                cmd.Parameters.AddWithValue("@PostBox", st.PostBox);  
                cmd.ExecuteNonQuery();
            }
        }

        public void UpdateCustomer(Models.Customer st)
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("UpdateCustomer", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id", st.Id);
                cmd.Parameters.AddWithValue("@FirstName", st.FirstName);
                cmd.Parameters.AddWithValue("@LastName", st.LastName);
                cmd.Parameters.AddWithValue("@Gender", st.Gender);
                cmd.Parameters.AddWithValue("@eMail", st.eMail);
                cmd.Parameters.AddWithValue("@Mobile", st.Mobile);
                cmd.Parameters.AddWithValue("@City", st.City);
                cmd.Parameters.AddWithValue("@PostBox", st.PostBox);
                cmd.ExecuteNonQuery();
            }
        }

        public void DeleteCustomer(int id)
        {
            using (SqlConnection con = new SqlConnection(conString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("DeleteCustomer", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id", id);
                cmd.ExecuteNonQuery();
            }
        }        
    }
}