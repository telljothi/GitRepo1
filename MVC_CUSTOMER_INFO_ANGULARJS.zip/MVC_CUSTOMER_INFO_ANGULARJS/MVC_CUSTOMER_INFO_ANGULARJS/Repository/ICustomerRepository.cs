﻿using MVC_CUSTOMER_INFO_ANGULARJS.Models;
using System.Collections.Generic;

namespace MVC_CUSTOMER_INFO_ANGULARJS.Repository
{
    interface ICustomerRepository
    {
        List<Customer> SelectAllCustomers();       
        void InsertCustomer(Customer st);
        void UpdateCustomer(Customer st);
        void DeleteCustomer(int id);        
    }
}
